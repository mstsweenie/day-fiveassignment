## Homework

* Finish the in class work if you have not done so already.
* Finalize all of the week's homework by completing all the needed pages for your personal site
* Feel free to utilize bootstrap or use custom styling as you prefer
* Using what you know about RWD and mobile first, use those skills to better your site.
* Ensure that you only have a single custom css file that you use across all of your pages.
* Add custom fonts as you see fit
* Host the repository on GitHub Pages.